<?php

/**
 * Plugin Name: Spacefast Identity
 * Description: Standalone accounts, verified emails and OpenID Connect for WordPress.
 * Version: 0.1.0
 * Requires at least: 6.8
 * Requires PHP: 8.2
 * License: GPL-2.0-or-later
 * Text Domain: spacefast-identity
 */
declare (strict_types=1);
namespace SpacefastIdentityVendor;

if (!\defined("ABSPATH")) {
    exit;
}
require_once __DIR__ . "/vendor/autoload.php";
require_once __DIR__ . "/src/Protocol.php";
\register_activation_hook(__FILE__, static function () {
    global $wpdb;
    \Spacefast\Identity\Schema::migrate(new \Spacefast\Identity\DB($wpdb));
    \Spacefast\Identity\Keys::current();
    if (!\wp_next_scheduled("spacefast_identity_maintenance")) {
        \wp_schedule_event(\time() + 60, "hourly", "spacefast_identity_maintenance");
    }
});
\register_deactivation_hook(__FILE__, static function () {
    \wp_clear_scheduled_hook("spacefast_identity_maintenance");
});
\Spacefast\Identity\Plugin::boot(__FILE__);
