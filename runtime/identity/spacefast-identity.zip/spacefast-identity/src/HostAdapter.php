<?php

declare (strict_types=1);
namespace Spacefast\Identity;

final class HostAdapter
{
    public static function beforeRuntime(): void
    {
        self::withIdentityLock(self::beforeRuntimeLocked(...));
    }
    public static function afterRuntime(): void
    {
        self::withIdentityLock(self::afterRuntimeLocked(...));
    }
    private static function withIdentityLock(callable $operation): void
    {
        $identity = function_exists("spacefast_content_principal_identity") ? spacefast_content_principal_identity() : null;
        if (is_array($identity) && ($identity["kind"] ?? "") === "user" && function_exists("spacefast_space_users_identity_lock")) {
            spacefast_space_users_identity_lock($identity["issuer"], $identity["subject"], $operation);
            return;
        }
        $operation();
    }
    private static function beforeRuntimeLocked(): void
    {
        if (!function_exists("spacefast_content_principal_identity") || !function_exists("spacefast_content_principal_find_user")) {
            return;
        }
        $identity = spacefast_content_principal_identity();
        if (!is_array($identity) || ($identity["kind"] ?? "") !== "user") {
            return;
        }
        $key = hash("sha256", $identity["issuer"] . "\x00" . $identity["subject"]);
        $row = \Spacefast\Identity\Plugin::$db->row("SELECT wp_user_id FROM " . \Spacefast\Identity\Plugin::$db->prefix . "providers WHERE identity_key=%s", $key);
        if (!$row) {
            return;
        }
        $uid = (int) $row["wp_user_id"];
        $existing = spacefast_content_principal_find_user($identity["principal_id"], $identity["issuer"], $identity["subject"]);
        if ($existing && $existing !== $uid) {
            throw new \Spacefast\Identity\Failure("runtime_identity_conflict", "Runtime identity mapping conflicts with the account mapping.", 409);
        }
        if (!get_userdata($uid)) {
            throw new \Spacefast\Identity\Failure("account_unavailable", "Runtime account no longer exists.", 403);
        }
        // The verified host principal carries its own grant authority, independent of local suspension.
        update_option("spacefast_principal_" . substr(hash("sha256", $identity["principal_id"]), 0, 40), ["version" => 1, "principal_id" => $identity["principal_id"], "kind" => "user", "issuer" => $identity["issuer"], "subject" => $identity["subject"], "user_id" => $uid], \false);
    }
    private static function afterRuntimeLocked(): void
    {
        if (!function_exists("spacefast_content_principal_identity")) {
            return;
        }
        $identity = spacefast_content_principal_identity();
        if (!is_array($identity) || ($identity["kind"] ?? "") !== "user") {
            return;
        }
        $uid = spacefast_content_principal_find_user($identity["principal_id"], $identity["issuer"], $identity["subject"]);
        if (!$uid) {
            return;
        }
        $key = hash("sha256", $identity["issuer"] . "\x00" . $identity["subject"]);
        \Spacefast\Identity\Plugin::$accounts->ensure($uid);
        \Spacefast\Identity\Plugin::$db->transaction(function () use ($uid, $key, $identity) {
            \Spacefast\Identity\Plugin::$db->run("SELECT wp_user_id FROM " . \Spacefast\Identity\Plugin::$db->prefix . "accounts WHERE wp_user_id=%d FOR UPDATE", $uid);
            $row = \Spacefast\Identity\Plugin::$db->row("SELECT wp_user_id FROM " . \Spacefast\Identity\Plugin::$db->prefix . "providers WHERE identity_key=%s", $key);
            if ($row) {
                if ((int) $row["wp_user_id"] !== $uid) {
                    throw new \Spacefast\Identity\Failure("runtime_identity_conflict", "Runtime identity mapping conflicts.", 409);
                }
                return;
            }
            \Spacefast\Identity\Plugin::$db->insert("providers", ["wp_user_id" => $uid, "identity_key" => $key, "issuer" => $identity["issuer"], "subject" => $identity["subject"], "created_at" => time()]);
        });
    }
}
