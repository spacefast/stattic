<?php

declare (strict_types=1);
namespace Spacefast\Identity;

use SpacefastIdentityVendor\Lcobucci\JWT\Configuration;
use SpacefastIdentityVendor\Lcobucci\JWT\Signer\Rsa\Sha256;
use SpacefastIdentityVendor\Lcobucci\JWT\Signer\Key\InMemory;
final class Keys
{
    public static function rotate(): void
    {
        $resource = openssl_pkey_new(["private_key_bits" => 2048, "private_key_type" => \OPENSSL_KEYTYPE_RSA]);
        if ($resource === \false || !openssl_pkey_export($resource, $private)) {
            throw new \Spacefast\Identity\Failure("key_generation_failed", "Signing key generation failed.", 500);
        }
        $details = openssl_pkey_get_details($resource);
        $keys = get_option("sfi_signing_keys", []);
        foreach ($keys as &$key) {
            if (!isset($key["retire_at"])) {
                $key["retire_at"] = time() + 600;
            }
        }
        unset($key);
        $keys = array_filter($keys, fn($k) => ($k["retire_at"] ?? \PHP_INT_MAX) > time());
        array_unshift($keys, ["kid" => bin2hex(random_bytes(12)), "private" => \Spacefast\Identity\Security::seal($private), "public" => $details["key"], "n" => rtrim(strtr(base64_encode($details["rsa"]["n"]), "+/", "-_"), "="), "e" => rtrim(strtr(base64_encode($details["rsa"]["e"]), "+/", "-_"), "=")]);
        update_option("sfi_signing_keys", array_values($keys), \false);
        if (!get_option("sfi_oauth_encryption")) {
            update_option("sfi_oauth_encryption", \Spacefast\Identity\Security::seal(\Spacefast\Identity\Security::token()), \false);
        }
    }
    public static function current(): array
    {
        $keys = get_option("sfi_signing_keys", []);
        if (!$keys) {
            self::rotate();
            $keys = get_option("sfi_signing_keys");
        }
        return $keys[0];
    }
    public static function config(array $key): Configuration
    {
        return Configuration::forAsymmetricSigner(new Sha256(), InMemory::plainText(\Spacefast\Identity\Security::open($key["private"])), InMemory::plainText($key["public"]));
    }
    public static function jwks(): array
    {
        self::current();
        return ["keys" => array_values(array_map(fn($k) => ["kty" => "RSA", "use" => "sig", "alg" => "RS256", "kid" => $k["kid"], "n" => $k["n"], "e" => $k["e"]], array_filter(get_option("sfi_signing_keys"), fn($k) => ($k["retire_at"] ?? \PHP_INT_MAX) > time())))];
    }
}
