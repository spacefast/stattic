<?php

declare (strict_types=1);
namespace Spacefast\Identity;

use SpacefastIdentityVendor\Firebase\JWT\JWT;
use SpacefastIdentityVendor\Firebase\JWT\JWK;
final class OidcClient extends \SpacefastIdentityVendor\Jumbojett\OpenIDConnectClient
{
    public array $store = [];
    public string $destination = "";
    private string $algorithm = "RS256";
    public function allowAlgorithm(string $algorithm): void
    {
        if (!in_array($algorithm, ["RS256", "EdDSA"], \true)) {
            throw new \InvalidArgumentException("Unsupported provider algorithm");
        }
        $this->algorithm = $algorithm;
    }
    protected function getSessionKey(string $key)
    {
        return $this->store[$key] ?? \false;
    }
    protected function setSessionKey(string $key, $value)
    {
        $this->store[$key] = $value;
    }
    protected function unsetSessionKey(string $key)
    {
        unset($this->store[$key]);
    }
    protected function commitSession()
    {
    }
    public function redirect(string $url)
    {
        $this->destination = $url;
    }
    public function verifyJWTSignature(string $jwt): bool
    {
        $header = $this->decodeJWT($jwt);
        if (!is_object($header) || ($header->alg ?? null) !== $this->algorithm || !is_string($header->kid ?? null) || isset($header->jwk) || isset($header->jku) || isset($header->x5u)) {
            return \false;
        }
        $jwks = json_decode($this->fetchURL($this->getProviderConfigValue("jwks_uri")), \true, 32, \JSON_THROW_ON_ERROR);
        if (!is_array($jwks["keys"] ?? null)) {
            return \false;
        }
        $keys = array_values(array_filter($jwks["keys"], fn($k) => is_array($k) && ($k["kid"] ?? null) === $header->kid && ($k["alg"] ?? $this->algorithm) === $this->algorithm && ($k["use"] ?? "sig") === "sig" && ($this->algorithm === "EdDSA" ? ($k["kty"] ?? null) === "OKP" && ($k["crv"] ?? null) === "Ed25519" : ($k["kty"] ?? null) === "RSA")));
        if (count($keys) !== 1) {
            return \false;
        }
        try {
            JWT::decode($jwt, JWK::parseKeySet(["keys" => $keys], $this->algorithm));
            return \true;
        } catch (\Throwable $e) {
            return \false;
        }
    }
    protected function verifyJWTClaims($claims, ?string $accessToken = null): bool
    {
        $aud = $claims->aud ?? null;
        if (!is_string($aud) && !is_array($aud)) {
            return \false;
        }
        if (is_string($aud) && $aud !== $this->getClientID()) {
            return \false;
        }
        if (is_array($aud) && (!in_array($this->getClientID(), $aud, \true) || count($aud) > 1 && ($claims->azp ?? null) !== $this->getClientID())) {
            return \false;
        }
        if (isset($claims->azp) && $claims->azp !== $this->getClientID()) {
            return \false;
        }
        if (!is_string($claims->sub ?? null) || $claims->sub === "" || !is_string($claims->iss ?? null) || !$this->validateIssuer($claims->iss) || !is_int($claims->exp ?? null) || !is_int($claims->iat ?? null) || $claims->iat > time() + 30 || $claims->exp <= time() || !is_string($claims->nonce ?? null) || !hash_equals((string) $this->getNonce(), $claims->nonce)) {
            return \false;
        }
        if (isset($claims->nbf) && (!is_int($claims->nbf) || $claims->nbf > time() + 30)) {
            return \false;
        }
        if (isset($claims->at_hash)) {
            if (!is_string($claims->at_hash) || $accessToken === null) {
                return \false;
            }
            $hash = hash($this->algorithm === "EdDSA" ? "sha512" : "sha256", $accessToken, \true);
            $expected = rtrim(strtr(base64_encode(substr($hash, 0, intdiv(strlen($hash), 2))), "+/", "-_"), "=");
            if (!hash_equals($expected, $claims->at_hash)) {
                return \false;
            }
        }
        return ($this->getIdTokenHeader()->alg ?? null) === $this->algorithm;
    }
}
