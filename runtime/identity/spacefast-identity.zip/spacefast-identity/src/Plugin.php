<?php

declare (strict_types=1);
namespace Spacefast\Identity;

final class Plugin
{
    public static \Spacefast\Identity\DB $db;
    public static \Spacefast\Identity\Accounts $accounts;
    public static \Spacefast\Identity\Sessions $sessions;
    public static \Spacefast\Identity\Security $security;
    public static \Spacefast\Identity\Api $api;
    public static function boot(string $file): void
    {
        global $wpdb;
        self::$db = new \Spacefast\Identity\DB($wpdb);
        self::$security = new \Spacefast\Identity\Security(self::$db);
        self::$accounts = new \Spacefast\Identity\Accounts(self::$db, self::$security);
        self::$sessions = new \Spacefast\Identity\Sessions(self::$db, self::$security);
        self::$api = new \Spacefast\Identity\Api(self::$db, self::$accounts, self::$sessions, self::$security, new \Spacefast\Identity\Mfa(self::$db, self::$security));
        if ((int) get_option("sfi_schema_version", 0) < 1) {
            \Spacefast\Identity\Schema::migrate(self::$db);
        }
        add_action("rest_api_init", [self::$api, "register"]);
        add_filter("rest_pre_serve_request", static function ($served, $result, $request) {
            if (str_starts_with($request->get_route(), "/spacefast-identity/v1/")) {
                header_remove("Access-Control-Allow-Origin");
                header_remove("Access-Control-Allow-Credentials");
                header("Vary: Origin", \false);
            }
            return $served;
        }, 20, 3);
        add_action("template_redirect", fn() => self::page($file), 0);
        add_filter("admin_body_class", static fn($classes) => $classes . (($_GET["page"] ?? "") === "spacefast-identity" ? " sfi-admin-screen" : ""));
        add_action("admin_menu", static function () use ($file) {
            add_menu_page("Identity", "Identity", "manage_options", "spacefast-identity", fn() => self::adminPage($file), "dashicons-admin-users", 3);
        });
        add_filter("authenticate", static function ($user, $login, $password) {
            if ($user instanceof \WP_User || !is_string($login) || !is_email($login)) {
                return $user;
            }
            if (is_wp_error($user) && array_diff($user->get_error_codes(), ["invalid_username", "invalid_email", "incorrect_password"])) {
                return $user;
            }
            try {
                $uid = self::$accounts->owner($login);
            } catch (\Spacefast\Identity\Failure $e) {
                return $user;
            }
            $account = $uid ? get_userdata($uid) : \false;
            return $account ? wp_authenticate_username_password(null, $account->user_login, $password) : $user;
        }, 21, 3);
        add_filter("authenticate", static function ($user) {
            if ($user instanceof \WP_User) {
                $row = self::$db->row("SELECT status FROM " . self::$db->prefix . "accounts WHERE wp_user_id=%d", $user->ID);
                if ($row && $row["status"] !== "active") {
                    return new \WP_Error("account_unavailable", "This account is unavailable.");
                }
            }
            return $user;
        }, 100);
        add_filter("wp_authenticate_user", static function ($user) {
            if ($user instanceof \WP_User && (new \Spacefast\Identity\Mfa(self::$db, self::$security))->enabled((int) $user->ID)) {
                return new \WP_Error("identity_mfa_required", "Use the Identity sign-in page to complete multifactor authentication.");
            }
            return $user;
        }, 100);
        add_action("plugins_loaded", [\Spacefast\Identity\HostAdapter::class, "beforeRuntime"], 0);
        add_action("plugins_loaded", [\Spacefast\Identity\HostAdapter::class, "afterRuntime"], 2);
        add_action("spacefast_identity_maintenance", fn() => (new \Spacefast\Identity\Maintenance(self::$db, self::$security))->run());
        add_filter("wp_privacy_personal_data_exporters", static function ($exporters) {
            $exporters["spacefast-identity"] = ["exporter_friendly_name" => "Spacefast Identity", "callback" => static function ($email) {
                $uid = self::$accounts->owner($email);
                return ["data" => $uid ? [["group_id" => "identity", "group_label" => "Identity account", "item_id" => "identity-" . $uid, "data" => [["name" => "Account", "value" => wp_json_encode((new \Spacefast\Identity\Privacy(self::$db, self::$security))->export($uid))]]]] : [], "done" => \true];
            }];
            return $exporters;
        });
        add_filter("wp_privacy_personal_data_erasers", static function ($erasers) {
            $erasers["spacefast-identity"] = ["eraser_friendly_name" => "Spacefast Identity", "callback" => static function ($email) {
                $uid = self::$accounts->owner($email);
                if (!$uid) {
                    return ["items_removed" => \false, "items_retained" => \false, "messages" => [], "done" => \true];
                }
                try {
                    (new \Spacefast\Identity\Privacy(self::$db, self::$security))->erase($uid);
                    return ["items_removed" => \true, "items_retained" => \false, "messages" => ["Identity data erased; authored content retains an anonymous WordPress author."], "done" => \true];
                } catch (\Spacefast\Identity\Failure $e) {
                    return ["items_removed" => \false, "items_retained" => \true, "messages" => [$e->getMessage()], "done" => \true];
                }
            }];
            return $erasers;
        });
        add_action("wp_abilities_api_init", static function () {
            if (function_exists("wp_register_ability")) {
                wp_register_ability("spacefast-identity/account", ["label" => "Get identity account", "description" => "Read a WordPress identity account.", "input_schema" => ["type" => "object", "properties" => ["id" => ["type" => "integer"]], "required" => ["id"]], "permission_callback" => fn() => current_user_can("list_users"), "execute_callback" => fn($input) => self::$accounts->profile((int) $input["id"])]);
            }
        });
        if (defined("WP_CLI") && \WP_CLI) {
            \WP_CLI::add_command("identity", new \Spacefast\Identity\Cli());
        }
    }
    private static function json(array $data, int $status = 200): never
    {
        status_header($status);
        header("Content-Type: application/json");
        header("Cache-Control: no-store");
        echo wp_json_encode($data);
        exit;
    }
    private static function page(string $file): void
    {
        $path = wp_parse_url($_SERVER["REQUEST_URI"] ?? "/", \PHP_URL_PATH);
        $base = wp_parse_url(home_url("/identity"), \PHP_URL_PATH);
        if ($path !== "/.well-known/openid-configuration" && !str_starts_with($path, $base)) {
            return;
        }
        $canonical = wp_parse_url(home_url());
        $canonicalHost = $canonical["host"] . (isset($canonical["port"]) ? ":" . $canonical["port"] : "");
        if (($_SERVER["HTTP_HOST"] ?? "") !== $canonicalHost) {
            wp_safe_redirect($canonical["scheme"] . "://" . $canonicalHost . ($_SERVER["REQUEST_URI"] ?? "/identity"), 303);
            exit;
        }
        if (!is_ssl() && !(defined("SPACEFAST_IDENTITY_DEV_HTTP") && \SPACEFAST_IDENTITY_DEV_HTTP && wp_get_environment_type() === "local")) {
            self::json(["error" => "https_required"], 400);
        }
        nocache_headers();
        header("Referrer-Policy: same-origin");
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: DENY");
        try {
            $route = substr($path, strlen($base));
            if ($path === "/.well-known/openid-configuration" || $route === "/.well-known/openid-configuration") {
                self::json(\Spacefast\Identity\OAuth::discovery());
            }
            if ($route === "/jwks") {
                self::json(\Spacefast\Identity\Keys::jwks());
            }
            if ($route === "/token") {
                if ($_SERVER["REQUEST_METHOD"] !== "POST") {
                    self::json(["error" => "invalid_request"], 405);
                }
                self::$security->limit("token:" . ($_SERVER["REMOTE_ADDR"] ?? ""), 60);
                $response = (new \Spacefast\Identity\OAuth(self::$db, self::$accounts))->token($_POST);
                status_header($response->getStatusCode());
                foreach ($response->getHeaders() as $name => $values) {
                    header($name . ": " . implode(", ", $values));
                }
                echo $response->getBody();
                exit;
            }
            if ($route === "/userinfo") {
                $authorization = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
                if (!str_starts_with($authorization, "Bearer ")) {
                    self::json(["error" => "invalid_token"], 401);
                }
                self::json((new \Spacefast\Identity\OAuth(self::$db, self::$accounts))->userinfo(substr($authorization, 7)));
            }
            if ($route === "/provider/start") {
                $name = sanitize_key($_GET["provider"] ?? "");
                $url = (new \Spacefast\Identity\Providers(self::$security, self::$accounts, self::$sessions))->start($name);
                wp_redirect($url);
                exit;
            }
            if ($route === "/provider/callback") {
                $uid = (new \Spacefast\Identity\Providers(self::$security, self::$accounts, self::$sessions))->callback(sanitize_key($_GET["provider"] ?? ""));
                $result = self::$api->providerLogin($uid);
                wp_safe_redirect(home_url("/identity") . ($result["kind"] === "mfa_required" ? "?factor=" . rawurlencode($result["challenge_id"]) : ""));
                exit;
            }
            if ($route === "/authorize") {
                $query = $_SERVER["REQUEST_METHOD"] === "POST" ? $_POST : $_GET;
                if (isset($query["resume"])) {
                    [$resumeId, $resumeSecret] = array_pad(explode(".", (string) ($_COOKIE["sfi_reauth"] ?? ""), 2), 2, "");
                    $resume = self::$security->consume($resumeId, "authorize_reauth", $resumeSecret);
                    $freshSession = self::$sessions->require();
                    if ($freshSession["id"] === $resume["payload"]["prior_session"] || (int) $freshSession["created_at"] < $resume["payload"]["requested_at"]) {
                        throw new \Spacefast\Identity\Failure("login_required", "A fresh sign-in is required.", 401);
                    }
                    $query = $resume["payload"]["query"];
                    $query["prompt"] = "consent";
                    unset($query["max_age"]);
                }
                $oauth = new \Spacefast\Identity\OAuth(self::$db, self::$accounts);
                $auth = $oauth->authorization($query);
                $session = self::$sessions->find((string) ($_COOKIE[\Spacefast\Identity\Sessions::COOKIE] ?? ""));
                if ($_SERVER["REQUEST_METHOD"] === "GET" && (($query["prompt"] ?? "") === "login" || isset($query["max_age"]) && (!$session || (int) $session["verified_at"] < time() - (int) $query["max_age"]))) {
                    $binding = \Spacefast\Identity\Security::token();
                    $resumeId = self::$security->challenge("authorize_reauth", 0, "", ["query" => $query, "prior_session" => $session["id"] ?? "", "requested_at" => time()], $binding);
                    setcookie("sfi_reauth", $resumeId . "." . $binding, ["expires" => time() + 300, "path" => "/identity", "secure" => is_ssl(), "httponly" => \true, "samesite" => "Lax"]);
                    wp_safe_redirect(home_url("/identity?reauth=1"));
                    exit;
                }
                if (!$session) {
                    wp_safe_redirect(home_url("/identity?return_to=" . rawurlencode("/identity/authorize?" . http_build_query($query))));
                    exit;
                }
                if ($_SERVER["REQUEST_METHOD"] === "POST") {
                    \Spacefast\Identity\Api::checkOrigin((string) ($_SERVER["HTTP_ORIGIN"] ?? ""), \true);
                    self::$sessions->require(is_string($_POST["csrf"] ?? null) ? $_POST["csrf"] : "");
                    if (isset($query["max_age"]) && (!ctype_digit((string) $query["max_age"]) || (int) $session["verified_at"] < time() - (int) $query["max_age"])) {
                        throw new \Spacefast\Identity\Failure("login_required", "Confirm your identity in Account, then retry.", 401);
                    }
                    $url = $oauth->authorize($query, $session);
                    wp_redirect($url);
                    exit;
                }
                status_header(200);
                echo '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>Authorize application</title><link rel="stylesheet" href="' . esc_url(plugins_url("build/hosted.css", $file)) . '"></head><body><main class="consent"><div class="brand">◈ Spacefast</div><h1>Continue to ' . esc_html($auth->getClient()->getName()) . "</h1><p>This application will receive your identity and the profile fields you approve.</p><p>Requested: " . esc_html(implode(", ", array_map(fn($s) => $s->getIdentifier(), $auth->getScopes()))) . '</p><form method="post">';
                foreach ($query as $key => $value) {
                    if (is_string($value)) {
                        echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
                    }
                }
                echo '<input type="hidden" name="csrf" value="' . esc_attr($session["csrf"]) . '"><button>Allow and continue</button></form><a href="' . esc_url(home_url("/identity")) . '">Cancel</a></main></body></html>';
                exit;
            }
            if (!in_array($route, ["", "/", "/account"], \true)) {
                self::json(["error" => "not_found"], 404);
            }
            status_header(200);
            echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Spacefast Identity</title><link rel="stylesheet" href="' . esc_url(plugins_url("build/hosted.css", $file)) . '"></head><body><div id="identity-root" data-api="' . esc_url(rest_url("spacefast-identity/v1/")) . '"></div><script type="module" src="' . esc_url(plugins_url("build/hosted.js", $file)) . '"></script></body></html>';
            exit;
        } catch (\SpacefastIdentityVendor\League\OAuth2\Server\Exception\OAuthServerException $e) {
            self::json(["error" => $e->getErrorType(), "error_description" => $e->getMessage()], $e->getHttpStatusCode());
        } catch (\Spacefast\Identity\Failure $e) {
            self::json(["error" => $e->kind, "error_description" => $e->getMessage()], $e->status);
        } catch (\Throwable $e) {
            error_log("Identity protocol: " . get_class($e) . " " . $e->getMessage());
            self::json(["error" => "server_error"], 500);
        }
    }
    private static function adminPage(string $file): void
    {
        echo '<div id="identity-admin" data-api="' . esc_url(rest_url("spacefast-identity/v1/admin/")) . '" data-nonce="' . esc_attr(wp_create_nonce("wp_rest")) . '"></div>';
        wp_enqueue_style("spacefast-identity-admin", plugins_url("build/admin.css", $file), [], "0.1.0");
        wp_enqueue_script("spacefast-identity-admin", plugins_url("build/admin.js", $file), [], "0.1.0", \true);
    }
}
