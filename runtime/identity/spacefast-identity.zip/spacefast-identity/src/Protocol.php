<?php

declare (strict_types=1);
namespace Spacefast\Identity;

use SpacefastIdentityVendor\League\OAuth2\Server\Entities as E;
use SpacefastIdentityVendor\League\OAuth2\Server\Entities\Traits as T;
use SpacefastIdentityVendor\League\OAuth2\Server\Repositories as R;
use SpacefastIdentityVendor\League\OAuth2\Server\Exception\OAuthServerException;
use SpacefastIdentityVendor\Lcobucci\JWT\Signer\Rsa\Sha256;
use SpacefastIdentityVendor\Lcobucci\JWT\Signer\Key\InMemory;
use SpacefastIdentityVendor\Nyholm\Psr7\Response;
use SpacefastIdentityVendor\Nyholm\Psr7\ServerRequest;
final class Client implements E\ClientEntityInterface
{
    use T\EntityTrait;
    use T\ClientTrait;
    public function __construct(array $row)
    {
        $this->identifier = $row["id"];
        $this->name = $row["name"];
        $this->redirectUri = json_decode($row["redirects"], \true);
    }
}
final class Scope implements E\ScopeEntityInterface
{
    use T\EntityTrait;
    use T\ScopeTrait;
    public function __construct(string $id)
    {
        $this->identifier = $id;
    }
}
final class User implements E\UserEntityInterface
{
    use T\EntityTrait;
    public function __construct(string $id)
    {
        $this->identifier = $id;
    }
}
final class Code implements E\AuthCodeEntityInterface
{
    use T\EntityTrait;
    use T\TokenEntityTrait;
    use T\AuthCodeTrait;
}
final class Token implements E\AccessTokenEntityInterface
{
    use T\EntityTrait, T\TokenEntityTrait, T\AccessTokenTrait {
        toString as private leagueToString;
    }
    public function toString(): string
    {
        $key = \Spacefast\Identity\Keys::current();
        $config = \Spacefast\Identity\Keys::config($key);
        $now = new \DateTimeImmutable();
        return $config->builder(\SpacefastIdentityVendor\Lcobucci\JWT\Encoding\ChainedFormatter::withUnixTimestampDates())->withHeader("kid", $key["kid"])->issuedBy(\Spacefast\Identity\OAuth::issuer())->permittedFor($this->getClient()->getIdentifier())->identifiedBy($this->getIdentifier())->relatedTo((string) $this->getUserIdentifier())->issuedAt($now)->canOnlyBeUsedAfter($now)->expiresAt($this->getExpiryDateTime())->withClaim("scopes", array_map(fn($s) => $s->getIdentifier(), $this->getScopes()))->getToken($config->signer(), $config->signingKey())->toString();
    }
}
final class Repository implements R\ClientRepositoryInterface, R\ScopeRepositoryInterface, R\AccessTokenRepositoryInterface, R\AuthCodeRepositoryInterface, R\RefreshTokenRepositoryInterface
{
    public array $context = [];
    public function __construct(public \Spacefast\Identity\DB $db)
    {
    }
    public function getClientEntity(string $id): ?E\ClientEntityInterface
    {
        $r = $this->db->row("SELECT * FROM {$this->db->prefix}applications WHERE id=%s AND enabled=1", $id);
        return $r ? new \Spacefast\Identity\Client($r) : null;
    }
    public function validateClient(string $id, ?string $secret, ?string $grant): bool
    {
        return $grant === "authorization_code" && $this->getClientEntity($id) !== null;
    }
    public function getScopeEntityByIdentifier(string $id): ?E\ScopeEntityInterface
    {
        return in_array($id, ["openid", "profile", "email"], \true) ? new \Spacefast\Identity\Scope($id) : null;
    }
    public function finalizeScopes(array $scopes, string $grant, E\ClientEntityInterface $client, ?string $uid = null, ?string $code = null): array
    {
        if ($code !== null) {
            $row = $this->db->row("SELECT * FROM {$this->db->prefix}codes WHERE id=%s FOR UPDATE", $code);
            if (!$row || (int) $row["revoked"] || (int) $row["expires_at"] <= time()) {
                throw OAuthServerException::invalidGrant();
            }
            $this->context = $row;
            $this->live($row);
        }
        return $scopes;
    }
    private function live(array $row): void
    {
        $a = $this->db->row("SELECT * FROM {$this->db->prefix}accounts WHERE wp_user_id=%d FOR UPDATE", $row["wp_user_id"]);
        $s = $this->db->row("SELECT * FROM {$this->db->prefix}sessions WHERE id=%s AND revoked_at IS NULL AND expires_at>%d FOR UPDATE", $row["session_id"], time());
        if (!$a || $a["status"] !== "active" || !$s) {
            throw OAuthServerException::invalidGrant("Session no longer active");
        }
    }
    public function getNewToken(E\ClientEntityInterface $client, array $scopes, ?string $uid = null): E\AccessTokenEntityInterface
    {
        $t = new \Spacefast\Identity\Token();
        $t->setClient($client);
        $t->setUserIdentifier($uid);
        foreach ($scopes as $s) {
            $t->addScope($s);
        }
        return $t;
    }
    public function persistNewAccessToken(E\AccessTokenEntityInterface $t): void
    {
        $this->db->insert("tokens", ["id" => $t->getIdentifier(), "wp_user_id" => (int) $t->getUserIdentifier(), "client_id" => $t->getClient()->getIdentifier(), "session_id" => $this->context["session_id"], "expires_at" => $t->getExpiryDateTime()->getTimestamp()]);
    }
    public function revokeAccessToken(string $id): void
    {
        $this->db->run("UPDATE {$this->db->prefix}tokens SET revoked=1 WHERE id=%s", $id);
    }
    public function isAccessTokenRevoked(string $id): bool
    {
        return !$this->db->row("SELECT t.id FROM {$this->db->prefix}tokens t JOIN {$this->db->prefix}sessions s ON s.id=t.session_id JOIN {$this->db->prefix}accounts a ON a.wp_user_id=t.wp_user_id JOIN {$this->db->prefix}applications c ON c.id=t.client_id WHERE t.id=%s AND t.revoked=0 AND t.expires_at>%d AND s.revoked_at IS NULL AND s.expires_at>%d AND a.status='active' AND c.enabled=1", $id, time(), time());
    }
    public function getNewAuthCode(): E\AuthCodeEntityInterface
    {
        return new \Spacefast\Identity\Code();
    }
    public function persistNewAuthCode(E\AuthCodeEntityInterface $c): void
    {
        $this->live(["wp_user_id" => (int) $c->getUserIdentifier(), "session_id" => $this->context["session_id"]]);
        $this->db->insert("codes", ["id" => $c->getIdentifier(), "wp_user_id" => (int) $c->getUserIdentifier(), "client_id" => $c->getClient()->getIdentifier(), "session_id" => $this->context["session_id"], "nonce" => $this->context["nonce"], "auth_time" => $this->context["auth_time"], "expires_at" => $c->getExpiryDateTime()->getTimestamp()]);
    }
    public function revokeAuthCode(string $id): void
    {
        if ($this->db->run("UPDATE {$this->db->prefix}codes SET revoked=1 WHERE id=%s AND revoked=0", $id) !== 1) {
            throw OAuthServerException::invalidGrant();
        }
    }
    public function isAuthCodeRevoked(string $id): bool
    {
        $r = $this->db->row("SELECT revoked FROM {$this->db->prefix}codes WHERE id=%s FOR UPDATE", $id);
        return !$r || (bool) $r["revoked"];
    }
    public function getNewRefreshToken(): ?E\RefreshTokenEntityInterface
    {
        return null;
    }
    public function persistNewRefreshToken(E\RefreshTokenEntityInterface $t): void
    {
        throw new \LogicException("Refresh tokens are disabled.");
    }
    public function revokeRefreshToken(string $id): void
    {
    }
    public function isRefreshTokenRevoked(string $id): bool
    {
        return \true;
    }
}
final class IdTokenResponse extends \SpacefastIdentityVendor\League\OAuth2\Server\ResponseTypes\BearerTokenResponse
{
    public function __construct(private \Spacefast\Identity\Repository $repository, private \Spacefast\Identity\Accounts $accounts)
    {
    }
    protected function getExtraParams(E\AccessTokenEntityInterface $token): array
    {
        $scopes = array_map(fn($s) => $s->getIdentifier(), $token->getScopes());
        if (!in_array("openid", $scopes, \true)) {
            return [];
        }
        $key = \Spacefast\Identity\Keys::current();
        $config = \Spacefast\Identity\Keys::config($key);
        $context = $this->repository->context;
        $builder = $config->builder(\SpacefastIdentityVendor\Lcobucci\JWT\Encoding\ChainedFormatter::withUnixTimestampDates())->withHeader("kid", $key["kid"])->issuedBy(\Spacefast\Identity\OAuth::issuer())->permittedFor($token->getClient()->getIdentifier())->relatedTo((string) $token->getUserIdentifier())->issuedAt(new \DateTimeImmutable())->expiresAt($token->getExpiryDateTime())->withClaim("nonce", $context["nonce"])->withClaim("auth_time", (int) $context["auth_time"])->withClaim("sid", $context["session_id"]);
        foreach (\Spacefast\Identity\OAuth::claims($this->accounts->profile((int) $token->getUserIdentifier()), $scopes) as $name => $value) {
            if ($name !== "sub") {
                $builder = $builder->withClaim($name, $value);
            }
        }
        return ["id_token" => $builder->getToken($config->signer(), $config->signingKey())->toString()];
    }
}
final class OAuth
{
    public readonly \Spacefast\Identity\Repository $repository;
    private \SpacefastIdentityVendor\League\OAuth2\Server\AuthorizationServer $server;
    public function __construct(private \Spacefast\Identity\DB $db, private \Spacefast\Identity\Accounts $accounts)
    {
        $this->repository = new \Spacefast\Identity\Repository($db);
        $key = \Spacefast\Identity\Keys::current();
        $this->server = new \SpacefastIdentityVendor\League\OAuth2\Server\AuthorizationServer($this->repository, $this->repository, $this->repository, new \SpacefastIdentityVendor\League\OAuth2\Server\CryptKey(\Spacefast\Identity\Security::open($key["private"]), null, \false), \Spacefast\Identity\Security::open(get_option("sfi_oauth_encryption")), new \Spacefast\Identity\IdTokenResponse($this->repository, $accounts));
        $this->server->enableGrantType(new \SpacefastIdentityVendor\League\OAuth2\Server\Grant\AuthCodeGrant($this->repository, $this->repository, new \DateInterval("PT60S")), new \DateInterval("PT5M"));
    }
    public static function issuer(): string
    {
        return untrailingslashit(home_url("/identity"));
    }
    public static function discovery(): array
    {
        $base = self::issuer();
        return ["issuer" => $base, "authorization_endpoint" => $base . "/authorize", "token_endpoint" => $base . "/token", "userinfo_endpoint" => $base . "/userinfo", "jwks_uri" => $base . "/jwks", "response_types_supported" => ["code"], "grant_types_supported" => ["authorization_code"], "subject_types_supported" => ["public"], "id_token_signing_alg_values_supported" => ["RS256"], "token_endpoint_auth_methods_supported" => ["none"], "code_challenge_methods_supported" => ["S256"], "scopes_supported" => ["openid", "profile", "email"], "claims_supported" => ["sub", "iss", "aud", "exp", "iat", "nonce", "auth_time", "sid", "name", "email", "email_verified"]];
    }
    public function authorization(array $query): \SpacefastIdentityVendor\League\OAuth2\Server\RequestTypes\AuthorizationRequestInterface
    {
        if (($query["code_challenge_method"] ?? "") !== "S256" || !preg_match('/^[A-Za-z0-9_-]{43}$/', (string) ($query["code_challenge"] ?? "")) || !preg_match('/^[A-Za-z0-9_-]{16,255}$/', (string) ($query["nonce"] ?? "")) || strlen((string) ($query["state"] ?? "")) < 16 || strlen((string) ($query["state"] ?? "")) > 512 || !in_array("openid", explode(" ", (string) ($query["scope"] ?? "")), \true)) {
            throw new \Spacefast\Identity\Failure("invalid_authorization_request", "An OpenID request with state, nonce and S256 PKCE is required.");
        }
        if (isset($query["max_age"]) && (!is_scalar($query["max_age"]) || !ctype_digit((string) $query["max_age"]))) {
            throw new \Spacefast\Identity\Failure("invalid_max_age", "max_age must be a nonnegative integer.");
        }
        if (isset($query["prompt"]) && !in_array($query["prompt"], ["login", "consent"], \true)) {
            throw new \Spacefast\Identity\Failure("unsupported_prompt", "This prompt is not supported.");
        }
        return $this->server->validateAuthorizationRequest((new ServerRequest("GET", self::issuer() . "/authorize"))->withQueryParams($query));
    }
    public function authorize(array $query, array $session): string
    {
        return $this->db->transaction(function () use ($query, $session) {
            $auth = $this->authorization($query);
            if (($query["prompt"] ?? "") === "login" || isset($query["max_age"]) && (int) $session["verified_at"] < time() - (int) $query["max_age"]) {
                throw new \Spacefast\Identity\Failure("login_required", "A fresh sign-in is required.", 401);
            }
            $this->repository->context = ["session_id" => $session["id"], "nonce" => $query["nonce"], "auth_time" => (int) $session["verified_at"]];
            $auth->setUser(new \Spacefast\Identity\User((string) $session["wp_user_id"]));
            $auth->setAuthorizationApproved(\true);
            $response = $this->server->completeAuthorizationRequest($auth, new Response());
            return $response->getHeaderLine("Location");
        });
    }
    public function token(array $body): \SpacefastIdentityVendor\Psr\Http\Message\ResponseInterface
    {
        return $this->db->transaction(fn() => $this->server->respondToAccessTokenRequest((new ServerRequest("POST", self::issuer() . "/token"))->withParsedBody($body), new Response()));
    }
    public static function claims(array $profile, array $scopes): array
    {
        $claims = ["sub" => $profile["id"]];
        if (in_array("profile", $scopes, \true)) {
            $claims["name"] = $profile["name"];
        }
        if (in_array("email", $scopes, \true)) {
            foreach ($profile["emails"] as $email) {
                if ($email["primary"]) {
                    $claims["email"] = $email["email"];
                    $claims["email_verified"] = \true;
                }
            }
        }
        return $claims;
    }
    public function userinfo(string $raw): array
    {
        try {
            $key = \Spacefast\Identity\Keys::current();
            $config = \Spacefast\Identity\Keys::config($key);
            $token = $config->parser()->parse($raw);
            if (!$token instanceof \SpacefastIdentityVendor\Lcobucci\JWT\UnencryptedToken) {
                throw new \RuntimeException();
            }
            $kid = $token->headers()->get("kid");
            $valid = \false;
            foreach (get_option("sfi_signing_keys") as $k) {
                if ($k["kid"] === $kid && ($k["retire_at"] ?? \PHP_INT_MAX) > time()) {
                    $valid = $config->validator()->validate($token, new \SpacefastIdentityVendor\Lcobucci\JWT\Validation\Constraint\SignedWith(new Sha256(), InMemory::plainText($k["public"])), new \SpacefastIdentityVendor\Lcobucci\JWT\Validation\Constraint\IssuedBy(self::issuer()), new \SpacefastIdentityVendor\Lcobucci\JWT\Validation\Constraint\StrictValidAt(new class implements \SpacefastIdentityVendor\Psr\Clock\ClockInterface
                    {
                        public function now(): \DateTimeImmutable
                        {
                            return new \DateTimeImmutable("now", new \DateTimeZone("UTC"));
                        }
                    }));
                }
            }
            if (!$valid || $this->repository->isAccessTokenRevoked($token->claims()->get("jti"))) {
                throw new \RuntimeException();
            }
            $row = $this->db->row("SELECT * FROM {$this->db->prefix}tokens WHERE id=%s", $token->claims()->get("jti"));
            if (!in_array($row["client_id"], $token->claims()->get("aud"), \true) || (string) $row["wp_user_id"] !== $token->claims()->get("sub")) {
                throw new \RuntimeException();
            }
            return self::claims($this->accounts->profile((int) $row["wp_user_id"]), $token->claims()->get("scopes"));
        } catch (\Throwable $e) {
            throw new \Spacefast\Identity\Failure("invalid_token", "The access token is invalid or revoked.", 401);
        }
    }
}
