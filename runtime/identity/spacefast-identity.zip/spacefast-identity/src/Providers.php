<?php

declare (strict_types=1);
namespace Spacefast\Identity;

final class Providers
{
    public function __construct(private \Spacefast\Identity\Security $security, private \Spacefast\Identity\Accounts $accounts, private \Spacefast\Identity\Sessions $sessions)
    {
    }
    public static function config(): array
    {
        $providers = [];
        foreach (["google", "spacefast"] as $name) {
            $prefix = "SPACEFAST_IDENTITY_" . strtoupper($name) . "_";
            if (defined($prefix . "CLIENT_ID")) {
                $providers[$name] = ["issuer" => $name === "google" ? "https://accounts.google.com" : (defined($prefix . "ISSUER") ? constant($prefix . "ISSUER") : "https://api.spacefast.com/v1/auth"), "client_id" => constant($prefix . "CLIENT_ID"), "secret" => defined($prefix . "CLIENT_SECRET") ? constant($prefix . "CLIENT_SECRET") : ""];
            }
        }
        return apply_filters("spacefast_identity_providers", $providers);
    }
    public function client(string $name): \Spacefast\Identity\OidcClient
    {
        $config = self::config()[$name] ?? null;
        if (!$config) {
            throw new \Spacefast\Identity\Failure("provider_not_configured", "This sign-in provider has not been configured.", 503);
        }
        $client = new \Spacefast\Identity\OidcClient($config["issuer"], $config["client_id"], $config["secret"]);
        $client->allowAlgorithm($name === "spacefast" ? "EdDSA" : "RS256");
        $client->setRedirectURL(home_url("/identity/provider/callback?provider=" . rawurlencode($name)));
        $client->setCodeChallengeMethod("S256");
        $client->setTimeout(10);
        $client->addScope(["email", "profile"]);
        $client->setIssuerValidator(fn($issuer) => hash_equals($config["issuer"], $issuer));
        if ($name === "spacefast") {
            $url = preg_replace('~/v1/auth$~', "", $config["issuer"]) . "/.well-known/openid-configuration";
            $response = wp_remote_get($url, ["timeout" => 10, "redirection" => 0]);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                throw new \Spacefast\Identity\Failure("discovery_failed", "Spacefast discovery is unavailable.", 502);
            }
            $metadata = json_decode(wp_remote_retrieve_body($response), \true, 32, \JSON_THROW_ON_ERROR);
            if (($metadata["issuer"] ?? null) !== $config["issuer"]) {
                throw new \Spacefast\Identity\Failure("issuer_mismatch", "Spacefast discovery issuer does not match.", 502);
            }
            foreach (["authorization_endpoint", "token_endpoint", "userinfo_endpoint", "jwks_uri"] as $field) {
                if (!is_string($metadata[$field] ?? null) || parse_url($metadata[$field], \PHP_URL_SCHEME) !== "https" || parse_url($metadata[$field], \PHP_URL_HOST) !== parse_url($config["issuer"], \PHP_URL_HOST)) {
                    throw new \Spacefast\Identity\Failure("discovery_invalid", "Spacefast discovery endpoint is invalid.", 502);
                }
            }
            if (!in_array("EdDSA", $metadata["id_token_signing_alg_values_supported"] ?? [], \true)) {
                throw new \Spacefast\Identity\Failure("unsupported_provider_algorithm", "Spacefast must advertise EdDSA.", 502);
            }
            $client->providerConfigParam($metadata);
        }
        if (isset($config["discovery"])) {
            $client->providerConfigParam($config["discovery"]);
        }
        return $client;
    }
    public function start(string $name, ?array $linkSession = null): string
    {
        if ($linkSession) {
            $this->sessions->recent($linkSession);
        }
        $client = $this->client($name);
        $client->authenticate();
        if (!isset($client->store["openid_connect_code_verifier"])) {
            throw new \Spacefast\Identity\Failure("pkce_unavailable", "Provider does not support required PKCE.", 502);
        }
        $binding = \Spacefast\Identity\Security::token();
        $id = $this->security->challenge("oidc", (int) ($linkSession["wp_user_id"] ?? 0), (string) ($linkSession["id"] ?? ""), ["provider" => $name, "store" => $client->store], $binding, 300);
        setcookie("sfi_oidc", $id . "." . $binding, ["expires" => time() + 300, "path" => "/identity/provider/callback", "secure" => is_ssl(), "httponly" => \true, "samesite" => "Lax"]);
        return $client->destination;
    }
    public function callback(string $name): int
    {
        [$id, $binding] = array_pad(explode(".", (string) ($_COOKIE["sfi_oidc"] ?? ""), 2), 2, "");
        $challenge = $this->security->consume($id, "oidc", $binding);
        $payload = $challenge["payload"];
        if ($payload["provider"] !== $name || !is_string($_GET["state"] ?? null) || !hash_equals($payload["store"]["openid_connect_state"], $_GET["state"])) {
            throw new \Spacefast\Identity\Failure("invalid_state", "The provider sign-in expired or is invalid.");
        }
        $linkUid = (int) $challenge["wp_user_id"];
        if ($linkUid) {
            $session = $this->sessions->require();
            if ($session["id"] !== $challenge["session_id"]) {
                throw new \Spacefast\Identity\Failure("link_session_changed", "Sign in again before linking.", 403);
            }
            $this->sessions->recent($session);
        }
        $client = $this->client($name);
        $client->store = $payload["store"];
        try {
            $client->authenticate();
            $claims = $client->getVerifiedClaims();
            $info = $client->requestUserInfo();
            if (!is_object($info) || ($info->sub ?? null) !== $claims->sub) {
                throw new \RuntimeException("userinfo subject mismatch");
            }
        } catch (\Throwable $e) {
            $this->security->event(0, "provider.rejected", ["provider" => $name]);
            throw new \Spacefast\Identity\Failure("provider_validation_failed", "Provider identity could not be verified. Please start again.", 401);
        }
        $email = ($info->email_verified ?? \false) === \true && is_string($info->email ?? null) ? \Spacefast\Identity\Accounts::email($info->email) : null;
        return $this->accounts->provider($claims->iss, $claims->sub, $email, is_string($info->name ?? null) ? $info->name : "", $linkUid ?: null, $linkUid ? $challenge["session_id"] : null);
    }
}
