<?php

declare (strict_types=1);
namespace Spacefast\Identity;

final class Webhooks
{
    public static function register(string $url): array
    {
        $parts = wp_parse_url($url);
        if (!$parts || ($parts["scheme"] ?? "") !== "https" || isset($parts["user"]) || isset($parts["pass"]) || isset($parts["fragment"]) || !wp_http_validate_url($url)) {
            throw new \Spacefast\Identity\Failure("invalid_webhook_url", "Enter a public HTTPS webhook URL.");
        }
        $id = hash("sha256", $url);
        $endpoints = get_option("sfi_webhooks", []);
        foreach ($endpoints as $endpoint) {
            if ($endpoint["id"] === $id) {
                throw new \Spacefast\Identity\Failure("webhook_exists", "This endpoint is already registered.", 409);
            }
        }
        $secret = \Spacefast\Identity\Security::token();
        $endpoints[] = ["id" => $id, "url" => $url, "secret" => \Spacefast\Identity\Security::seal($secret)];
        update_option("sfi_webhooks", $endpoints, \false);
        return ["id" => $id, "secret" => $secret];
    }
    public static function remove(string $id): void
    {
        update_option("sfi_webhooks", array_values(array_filter(get_option("sfi_webhooks", []), fn($endpoint) => $endpoint["id"] !== $id)), \false);
    }
    public static function inventory(\Spacefast\Identity\DB $db): array
    {
        return array_map(fn($endpoint) => ["id" => $endpoint["id"], "url" => $endpoint["url"], "deliveries" => $db->rows("SELECT id,event_id,attempts,next_at,delivered_at,last_status FROM {$db->prefix}deliveries WHERE endpoint_id=%s ORDER BY id DESC LIMIT 20", $endpoint["id"])], get_option("sfi_webhooks", []));
    }
}
